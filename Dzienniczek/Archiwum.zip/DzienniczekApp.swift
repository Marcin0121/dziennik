import SwiftUI

@main
struct DzienniczekApp: App {
    var body: some Scene {
        WindowGroup {
            SplashScreenView() // Ustawienie SplashScreenView jako głównego widoku
        }
    }
}
